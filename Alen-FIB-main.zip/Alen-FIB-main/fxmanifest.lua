

fx_version 'adamant'

game 'gta5'

aurthor 'Alen#0007'

server_scripts {
	'server.lua',
	'config.lua',
}

client_scripts {
	'classes/datacrack.lua',
	'classes/cutscene.lua',
	'client.lua',
	'config.lua'
}

ui_page('html/index.html')

files {
    'html/index.html',
    'html/sounds/*.ogg',
}

