# cfx-server-data For RedM With Old Yarn and Session Manager
This version has the old yarn and sessionmanager-rdr3 files. I included the other files as well because the chat resource needed a Yarn dependency and the other resources are mostly unchanged compared to the latest version of cfx-server-data
## I didn't code any of this :)
