-- compatibility wrapper
fx_version 'adamant'
game 'common'

dependency 'basic-gamemode'