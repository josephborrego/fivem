client_script 'deathevents.lua'
client_script 'vehiclechecker.lua'
server_script 'server.lua'